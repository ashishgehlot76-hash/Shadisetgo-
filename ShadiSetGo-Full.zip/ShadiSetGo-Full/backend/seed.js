// Run this ONCE to create your admin login: node seed.js
require("dotenv").config();
const mongoose = require("mongoose");
const bcrypt = require("bcryptjs");
const User = require("./models/User");

async function seed() {
  await mongoose.connect(process.env.MONGO_URI);

  const phone = "9999999999"; // <-- CHANGE this to your real number before running
  const password = "admin123"; // <-- CHANGE this to a strong password before running

  const existing = await User.findOne({ phone });
  if (existing) {
    console.log("Admin pehle se bana hua hai is phone number se.");
    process.exit(0);
  }

  const passwordHash = await bcrypt.hash(password, 10);
  await User.create({
    name: "Admin",
    phone,
    passwordHash,
    role: "admin",
  });

  console.log("Admin account ban gaya!");
  console.log("Phone:", phone);
  console.log("Password:", password);
  process.exit(0);
}

seed();

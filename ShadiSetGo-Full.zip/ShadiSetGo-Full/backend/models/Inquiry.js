const mongoose = require("mongoose");

const inquirySchema = new mongoose.Schema(
  {
    customerId: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },
    category: {
      type: String,
      required: true,
      enum: ["photo", "dj", "catering", "mehendi", "decor", "venue", "cards", "pandit", "transport", "anchor"],
    },
    city: { type: String, required: true },
    eventDate: { type: Date, required: true },
    budget: { type: Number, required: true },
    message: { type: String },
    status: {
      type: String,
      enum: ["new", "assigned", "quoted", "deal_done", "closed"],
      default: "new",
    },
    assignedVendorIds: [{ type: mongoose.Schema.Types.ObjectId, ref: "Vendor" }],
    finalVendorId: { type: mongoose.Schema.Types.ObjectId, ref: "Vendor" },
    finalPrice: { type: Number },
    commissionRate: { type: Number, default: 0.1 }, // 10% default, admin can override per deal
    platformFee: { type: Number },
    vendorPayout: { type: Number },
  },
  { timestamps: true }
);

module.exports = mongoose.model("Inquiry", inquirySchema);

# ShadiSetGo — Deploy Karne Ka Poora Guide

Isme 2 parts hain:
1. **Backend** (`shadisetgo-backend` folder) — database aur saara logic
2. **Frontend** (`shadisetgo-frontend/app.html`) — jo customer/vendor/admin dekhenge

Neeche diye steps **order mein** follow karo.

---

## STEP 1 — Database Banao (MongoDB Atlas — Free)

1. https://www.mongodb.com/cloud/atlas/register par jaake free account banao
2. "Build a Database" → **FREE (M0)** option choose karo
3. Ek cluster create hoga (2-3 min lagega)
4. **Database Access** mein jaake ek username/password banao (yaad rakhna)
5. **Network Access** mein "Allow Access From Anywhere" (0.0.0.0/0) add karo
6. "Connect" button dabao → "Drivers" choose karo → ek connection string milegi jaisi:
   ```
   mongodb+srv://username:<password>@cluster0.xxxxx.mongodb.net/?retryWrites=true&w=majority
   ```
7. Isme `<password>` ki jagah apna real password daalo — ye string save karke rakho, isko **MONGO_URI** kehte hain

---

## STEP 2 — Backend Ko GitHub Par Daalo

1. https://github.com par free account banao (agar nahi hai)
2. Naya repository banao — naam do `shadisetgo-backend`
3. Is chat se download ki hui `shadisetgo-backend` folder ki saari files usme upload karo
   (GitHub website par "Add file" → "Upload files" se seedha upload ho jayega, drag-drop kar sakte ho)

---

## STEP 3 — Backend Ko Live Karo (Render.com — Free)

1. https://render.com par free account banao (GitHub se seedha sign up kar sakte ho)
2. "New +" → "Web Service" choose karo
3. Apna `shadisetgo-backend` GitHub repo connect karo
4. Settings:
   - **Build Command:** `npm install`
   - **Start Command:** `npm start`
5. "Environment Variables" section mein ye 2 daalo:
   - `MONGO_URI` = (Step 1 wali connection string)
   - `JWT_SECRET` = koi bhi lamba random text (jaise: `myShadiSetGoSecret2026xyz`)
6. "Create Web Service" dabao — 2-5 min mein deploy ho jayega
7. Aapko ek URL milega jaisa: `https://shadisetgo-backend.onrender.com`
   **Ye URL save karke rakho — agle step mein chahiye hoga**

### Admin Account Banana (Zaroori — Sirf Ek Baar)
Render ke dashboard mein "Shell" tab kholo (ya apne computer par local test karte waqt terminal mein), aur likho:
```
node seed.js
```
Isse pehle `seed.js` file mein apna real phone number aur password daal do (file mein comment mein likha hai kahan).

---

## STEP 4 — Frontend Ko Backend Se Jodo

1. `shadisetgo-frontend/app.html` file kholo (kisi text editor mein, jaise Notepad)
2. Ye line dhoondho (upar hi hai):
   ```
   const API_BASE = "http://localhost:5000/api";
   ```
3. Isko apne Render URL se badal do:
   ```
   const API_BASE = "https://shadisetgo-backend.onrender.com/api";
   ```
4. File save karo

---

## STEP 5 — Frontend Ko Live Karo (Netlify — Free, Sabse Aasan)

1. https://app.netlify.com/drop par jaao
2. Seedha `app.html` file ko us page par **drag-and-drop** karo
3. 10 second mein ek live link milega jaisa: `https://shadisetgo-123.netlify.app`
4. **Bas — aapki website live hai!** Ye link kisi ko bhi bhej sakte ho

---

## Test Kaise Karo

1. Live link kholo
2. "Register karo" se ek Customer account banao, dekhо vendors browse ho rahe hain
3. Ek naya Vendor account banao, profile submit karo
4. Apne admin phone/password se login karo (jo seed.js mein daala tha), vendor ko approve karo
5. Customer se inquiry bhejo, admin panel se vendor ko assign karo, vendor se quote lo, deal finalize karo

---

## Abhi Kya Missing Hai (Aage Add Karna Hoga)

- **Real Payment** — abhi payment collect nahi hota, sirf deal price record hoti hai. Business chalne lage to Razorpay add karwa sakte hain (isके liye aapko apna bank account + business documents Razorpay ko dene honge).
- **Real OTP Login** — abhi phone+password hai. OTP ke liye MSG91/Twilio jaisi SMS service ka paid account chahiye.
- **Photo/Video Upload** — abhi portfolio sirf text description hai, real image upload ke liye Cloudinary jaisi service add karni hogi.
- **Free tier ki limitation:** Render ka free plan thoda "so jata hai" agar 15 min koi use na kare — pehli request 30-50 second slow ho sakti hai. Business grow hone par paid plan (~$7/month) le sakte ho jo hamesha fast rahega.

Koi step mein atko to bata dena, us step ka screenshot bhi bhej sakte ho.
